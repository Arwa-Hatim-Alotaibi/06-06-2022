function Time() {
    var today = new Date();
    
    var hr = today.getHours();
    // Get current mn
    var mn = today.getMinutes();
    // Get current sc
    var sc = today.getSeconds();
    // Variable to store AM / PM
    var a = "";
    // Assigning AM / PM according to the current hr
    if (hr >= 12) {
    a = "PM";
    } else {
    a = "AM";
    }
    
    // Updating hr, mn, and sc
    // if they are less than 10
    hr = change(hr);
    mn = change(mn);
    sc = change(sc);
    // Adding time elements to the div
    document.getElementById("dc").innerText = hr + " : " + mn + " : " + sc + " " + a;
    // Set Timer to 1 sec (1000 ms)
    setTimeout(Time, 1000);
}
    // Function to change time elements if they are less than 10
    // Append 0 before time elements if they are less than 10
    function change(t) {
    if (t < 10) {
    return "0" + t;
    }
    else {
    return t;
    }
}
Time();